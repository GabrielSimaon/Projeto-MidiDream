#!/usr/bin/env python3
"""Converte stems de áudio em MIDI usando Basic Pitch e detecção espectral de bateria.

Uso:
  python audio2midi_corrigido.py "C:\\caminho\\da\\pasta_das_faixas" -o saida

Os arquivos de áudio podem estar dentro de subpastas. A pasta de saída é ignorada
na busca para evitar que WAVs temporários sejam processados na próxima execução.
"""

import os

os.environ["ORT_DISABLE_TELEMETRY"] = "1"

import argparse
import copy
import json
from live_vocals import parse_crowd_ranges, filter_vocal_notes
from note_cleanup import clean_notes, max_polyphony
from bass_pitch import validate_bass_pitch
from instrument_catalog import EXTRA, extra_kind
from musical_style import apply_style, DEFAULT_STYLE, style_drums
from rhythm_lock import lock_rhythm
from drum_timing import quantize_drums, split_hihat
from drum_classifier import classify_body, TOM_NOTES
from vocal_melody import transcribe_vocal_melody
import math
from functools import lru_cache
import re
import subprocess
from pathlib import Path

import librosa
import numpy as np
import pretty_midi
import scipy.ndimage

AUDIO_EXTS = {".mp3", ".wav", ".flac", ".m4a", ".ogg", ".aac", ".opus", ".webm"}

GM_PROGRAMS = {
    "vocals": (52, "Choir Aahs"),
    "bass": (33, "Bass"),
    "guitar": (25, "Guitar"),
    "piano": (0, "Piano"),
    "other": (0, "Other - Acompanhamento nao identificado"),
}

GM_PROGRAMS.update({kind: (program, name) for kind, (program, name, _) in EXTRA.items()})

# Limites do detector por instrumento: frequências em Hz e duração mínima em ms.
STEM_PARAMS = {
    "vocals": {
        "onset": 0.25,
        "frame": 0.15,
        "min_len": 50.0,
        "fmin": 85.0,
        "fmax": 1200.0,
        "pmin": 43,
        "pmax": 84,
        "min_vel": 10,
    },
    "bass": {
        "onset": 0.25,
        "frame": 0.15,
        "min_len": 50.0,
        "fmin": 28.0,
        "fmax": 400.0,
        "pmin": 24,
        "pmax": 60,
        "min_vel": 10,
    },
    "guitar": {
        "onset": 0.20,
        "frame": 0.12,
        "min_len": 40.0,
        "fmin": 75.0,
        "fmax": 1500.0,
        "pmin": 40,
        "pmax": 88,
        "min_vel": 8,
    },
    "piano": {
        "onset": 0.35,
        "frame": 0.22,
        "min_len": 60.0,
        "fmin": 27.5,
        "fmax": 4186.0,
        "pmin": 21,
        "pmax": 108,
        "min_vel": 8,
    },
    "other": {
        "onset": 0.20,
        "frame": 0.12,
        "min_len": 40.0,
        "fmin": 70.0,
        "fmax": 2500.0,
        "pmin": 40,
        "pmax": 88,
        "min_vel": 8,
    },
}

STEM_PARAMS["acoustic_guitar"] = dict(STEM_PARAMS["guitar"])
STEM_PARAMS["electric_guitar"] = dict(STEM_PARAMS["guitar"])
STEM_PARAMS["accordion"] = {**STEM_PARAMS["other"], "fmin": 100.0, "fmax": 4000.0, "pmin": 43, "pmax": 96, "min_len": 70.0}

# Não forçamos a escala de Si maior: a aplicação deve preservar a tonalidade
# e as notas detectadas da música original.
SCALE_CLASSES: set[int] = set()


def is_relative_to(path: Path, parent: Path) -> bool:
    """Verifica se um caminho está dentro de uma pasta."""
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def scan_audio_files(src_path: Path, output_path: Path) -> list[Path]:
    """Localiza arquivos de áudio, ignorando a pasta de saída."""
    if src_path.is_file():
        if src_path.suffix.lower() not in AUDIO_EXTS:
            raise ValueError(f"O arquivo informado não é um áudio compatível: {src_path}")
        return [src_path]
    if not src_path.is_dir():
        raise FileNotFoundError(f"A pasta de entrada não existe: {src_path}")

    found = []
    for p in src_path.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in AUDIO_EXTS:
            continue
        if is_relative_to(p, output_path):
            continue
        found.append(p)
    return sorted(found)


def classify_stem(path: Path) -> str:
    """Descobre se o áudio é baixo, bateria, voz ou acompanhamento pelo nome."""
    extra = extra_kind(path.stem)
    if extra:
        return extra
    low = path.stem.lower()
    if any(k in low for k in ("metro", "click", "metronome")):
        return "metronome"
    if any(k in low for k in ("drum", "bateria", "percuss")):
        return "drums"
    if any(k in low for k in ("bass", "baixo")):
        return "bass"
    if any(k in low for k in ("vocal", "voz", "voice")):
        return "vocals"
    if any(k in low for k in ("guitar", "violao", "violão", "guitarra")):
        return "guitar"
    if any(k in low for k in ("piano", "keys", "teclado")):
        return "piano"
    return "other"


def prepare_wav(src: Path, workdir: Path) -> Path:
    """Converte o áudio para WAV mono, no formato esperado pelos detectores."""
    workdir.mkdir(parents=True, exist_ok=True)
    # Prefixo com nome do arquivo mantém os stems separados na cache.
    dst = workdir / f"{src.stem}_norm.wav"
    subprocess.run(
        ["ffmpeg", "-y", "-i", str(src), "-ar", "22050", "-ac", "1", str(dst)],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return dst


def parse_bpm_hint(paths: list[Path]) -> float | None:
    """Procura uma indicação de BPM no nome dos arquivos."""
    for p in paths:
        match = re.search(r"(\d+(?:\.\d+)?)\s*bpm", p.stem.lower())
        if match:
            bpm = float(match.group(1))
            if 30.0 <= bpm <= 300.0:
                return bpm
    return None


def build_grid(
    max_duration: float, bpm: float, sub_div: int = 4, anchor: float = 0.0
) -> np.ndarray:
    """Cria a grade inteira até o fim dos stems, não só até o fim do metrônomo."""
    bpm = bpm if bpm > 0 else 158.0
    step = (60.0 / bpm) / max(1, sub_div)
    first_idx = math.floor((0.0 - anchor) / step)
    last_idx = math.ceil((max_duration - anchor) / step)
    indexes = np.arange(first_idx, last_idx + 1, dtype=np.float64)
    grid = anchor + indexes * step
    return grid[(grid >= 0.0) & (grid <= max_duration + step)]


def analyze_metronome(
    metro_path: Path | None,
    sub_div: int,
    max_duration: float,
    bpm_hint: float | None = None,
    reference_path: Path | None = None,
    fast: bool = False,
) -> tuple[float, np.ndarray]:
    """Usa o BPM informado ou estima pulsos do áudio e monta a grade rítmica."""
    bpm_detected = None
    anchor = 0.0
    if metro_path is not None:
        y, sr = librosa.load(str(metro_path), sr=44100, mono=True)
        hop = 256
        rms = librosa.feature.rms(y=y, frame_length=1024, hop_length=hop)[0]
        flux = np.maximum(0.0, np.diff(rms, prepend=0.0))
        if flux.size and flux.max() > 1e-6:
            flux /= flux.max()
            min_dist = max(1, int((0.15 * sr) / hop))
            local_max = scipy.ndimage.maximum_filter1d(flux, size=min_dist * 2 + 1)
            peaks = np.where((flux == local_max) & (flux >= 0.15))[0]
            clean_peaks = []
            for peak in peaks:
                if not clean_peaks or (peak - clean_peaks[-1]) >= min_dist:
                    clean_peaks.append(int(peak))
            click_times = librosa.frames_to_time(np.asarray(clean_peaks), sr=sr, hop_length=hop)
            if len(click_times) >= 2:
                median_ioi = float(np.median(np.diff(click_times)))
                if median_ioi > 0:
                    bpm_detected = 60.0 / median_ioi
                    anchor = float(click_times[0])

    # Se não houver BPM no nome nem metrônomo, estime-o a partir do áudio.
    bpm_audio = None
    if bpm_hint is None and bpm_detected is None and reference_path is not None:
        try:
            y_ref, sr_ref = librosa.load(
                str(reference_path), sr=22050, mono=True, duration=60.0 if fast else None
            )
            tempo_ref, beats_ref = librosa.beat.beat_track(
                y=y_ref, sr=sr_ref, hop_length=512, trim=False
            )
            tempo_ref = float(np.atleast_1d(tempo_ref)[0])
            if 40.0 <= tempo_ref <= 240.0:
                bpm_audio = tempo_ref
                if len(beats_ref) >= 16:
                    beat_seconds = librosa.frames_to_time(beats_ref, sr=sr_ref, hop_length=512)
                    indexes = np.arange(len(beat_seconds))
                    period, offset = np.polyfit(indexes, beat_seconds, 1)
                    residual = float(np.std(beat_seconds - (period * indexes + offset)))
                    refined = 60 / period
                    if abs(refined - tempo_ref) < tempo_ref * 0.08 and residual < 0.08:
                        bpm_audio = float(refined)
                        anchor = float((offset - 512 / sr_ref) % (period / max(1, sub_div)))
        except Exception as exc:
            print(f"[aviso] A estimativa de BPM pelo áudio falhou: {exc}")
    bpm = (
        bpm_hint
        if bpm_hint is not None
        else (bpm_detected if bpm_detected else (bpm_audio if bpm_audio else 120.0))
    )
    grid = build_grid(max_duration=max_duration, bpm=bpm, sub_div=sub_div, anchor=anchor)
    if bpm_hint is not None:
        print(f"[tempo] BPM pelo nome das faixas: {bpm:.2f}")
    elif bpm_detected is not None:
        print(f"[tempo] BPM estimado pelo metrônomo: {bpm:.2f}")
    elif bpm_audio is not None:
        print(f"[tempo] BPM estimado pelo áudio: {bpm:.2f}")
    else:
        print(f"[aviso] BPM não detectado; usando {bpm:.2f} BPM como aproximação.")
    print(f"[tempo] Grade gerada até {max_duration:.2f} segundos.")
    return bpm, grid


def snap_time_to_grid(t: float, grid_times: np.ndarray, step: float) -> float:
    """Move um instante em segundos para o ponto mais próximo da grade."""
    if grid_times.size:
        index = int(np.searchsorted(grid_times, t))
        if index == 0:
            return float(grid_times[0])
        if index == len(grid_times):
            return float(grid_times[-1])
        left, right = grid_times[index - 1], grid_times[index]
        return float(left if t - left <= right - t else right)
    return round(t / step) * step


def snap_to_scale(pitch: int) -> int:
    """Preserva a nota original; não há uma tonalidade fixa para todas as músicas."""
    return pitch


def rebuild_with_bpm(midi_in: pretty_midi.PrettyMIDI, bpm: float) -> pretty_midi.PrettyMIDI:
    """Copia notas em segundos para um novo MIDI com o andamento escolhido."""
    midi_out = pretty_midi.PrettyMIDI(initial_tempo=bpm, resolution=480)
    for inst in midi_in.instruments:
        new_inst = pretty_midi.Instrument(
            program=inst.program, is_drum=inst.is_drum, name=inst.name
        )
        for n in inst.notes:
            new_inst.notes.append(pretty_midi.Note(n.velocity, n.pitch, n.start, n.end))
        midi_out.instruments.append(new_inst)
    return midi_out


def post_process_notes(
    midi: pretty_midi.PrettyMIDI, stem: str, bpm: float, grid_times: np.ndarray, grid: int = 16
) -> pretty_midi.PrettyMIDI:
    """Filtra notas fora da faixa do instrumento e reúne sobreposições da mesma altura."""
    cfg = STEM_PARAMS.get(stem, STEM_PARAMS["other"])
    min_dur = cfg["min_len"] / 1000.0
    step = (60.0 / bpm) * (4.0 / grid) if grid else 0.0
    for inst in midi.instruments:
        if inst.is_drum:
            continue
        notes = [
            n
            for n in inst.notes
            if cfg["pmin"] <= n.pitch <= cfg["pmax"] and n.velocity >= cfg["min_vel"]
        ]
        for n in notes:
            n.pitch = snap_to_scale(n.pitch)
        notes.sort(key=lambda n: (n.pitch, n.start))
        merged = []
        for n in notes:
            if merged and merged[-1].pitch == n.pitch and n.start < merged[-1].end:
                merged[-1].end = max(merged[-1].end, n.end)
                merged[-1].velocity = max(merged[-1].velocity, n.velocity)
            else:
                merged.append(n)
        notes = [n for n in merged if (n.end - n.start) >= min_dur]
        for n in notes:
            q_start = snap_time_to_grid(n.start, grid_times, step) if grid else n.start
            q_end = snap_time_to_grid(n.end, grid_times, step) if grid else n.end
            n.start = max(0.0, q_start)
            n.end = max(n.start + 0.01, q_end)
        inst.notes = sorted(notes, key=lambda n: n.start)
    return midi


@lru_cache(maxsize=1)
def _pitch_model():
    """Carrega o modelo de notas uma única vez e reutiliza-o nas faixas seguintes."""
    try:
        import onnxruntime

        onnxruntime.disable_telemetry_events()
    except ImportError:
        pass
    from basic_pitch import ICASSP_2022_MODEL_PATH
    from basic_pitch.inference import Model

    return Model(ICASSP_2022_MODEL_PATH)


def transcribe_stem(wav: Path, stem: str) -> pretty_midi.PrettyMIDI:
    """Detecta notas polifônicas do áudio com Basic Pitch."""
    try:
        from basic_pitch import ICASSP_2022_MODEL_PATH
        from basic_pitch.inference import predict
    except ImportError as exc:
        raise RuntimeError(
            "A biblioteca Basic Pitch não está instalada neste Python. "
            "Instale-a no mesmo ambiente em que executa o script: pip install basic-pitch"
        ) from exc

    cfg = STEM_PARAMS.get(stem, STEM_PARAMS["other"])
    _, midi, _ = predict(
        str(wav),
        _pitch_model(),
        onset_threshold=cfg["onset"],
        frame_threshold=cfg["frame"],
        minimum_note_length=cfg["min_len"],
        minimum_frequency=cfg["fmin"],
        maximum_frequency=cfg["fmax"],
    )
    return midi


def transcribe_monophonic(wav: Path, stem: str) -> pretty_midi.PrettyMIDI:
    """Modo rápido: YIN para voz/baixo solo; não preserva coros ou acordes dessas pistas."""
    cfg = STEM_PARAMS[stem]
    y, sr = librosa.load(str(wav), sr=16000, mono=True)
    midi = pretty_midi.PrettyMIDI()
    instrument = pretty_midi.Instrument(GM_PROGRAMS[stem][0], name=GM_PROGRAMS[stem][1])
    midi.instruments.append(instrument)
    if not len(y) or float(np.max(np.abs(y))) < 1e-6:
        return midi
    hop, frame = 256, 2048
    f0 = librosa.yin(
        y, fmin=cfg["fmin"], fmax=cfg["fmax"], sr=sr, frame_length=frame, hop_length=hop
    )
    pitches = np.rint(librosa.hz_to_midi(f0)).astype(int)
    pitches = scipy.ndimage.median_filter(pitches, size=3)
    rms = librosa.feature.rms(y=y, frame_length=frame, hop_length=hop)[0]
    flatness = librosa.feature.spectral_flatness(y=y, n_fft=frame, hop_length=hop)[0]
    count = min(len(pitches), len(rms), len(flatness))
    threshold = max(1e-4, float(np.quantile(rms, 0.95)) * 0.04)
    valid = (rms[:count] > threshold) & (flatness[:count] < 0.25)
    pitches = np.where(valid, pitches[:count], -1)
    changes = np.r_[0, np.flatnonzero(pitches[1:] != pitches[:-1]) + 1, count]
    peak = max(float(np.quantile(rms, 0.95)), 1e-6)
    duration = len(y) / sr
    for start, stop in zip(changes[:-1], changes[1:]):
        pitch = int(pitches[start])
        t0, t1 = start * hop / sr, min(stop * hop / sr, duration)
        if cfg["pmin"] <= pitch <= cfg["pmax"] and t1 - t0 >= 0.06:
            velocity = int(np.clip(95 * np.sqrt(float(np.mean(rms[start:stop])) / peak), 25, 110))
            instrument.notes.append(pretty_midi.Note(velocity, pitch, t0, t1))
    return midi


def transcribe_drums(
    wav: Path, bpm: float, grid_times: np.ndarray, grid: int = 16, fast: bool = False
) -> pretty_midi.PrettyMIDI:
    """Detecta bumbo, caixa, tons/surdo e pratos com fluxo espectral + relação entre bandas.

    O método anterior normalizava cada filtro separadamente, então um prato com
    pouco conteúdo na faixa da caixa podia disparar as duas notas. Aqui as notas
    só são aceitas quando a energia relativa da região correspondente também é
    forte. Ataques realmente simultâneos continuam podendo gerar mais de uma nota.
    """
    y, sr = librosa.load(str(wav), sr=22050, mono=True)
    n_fft, hop = (1024, 256) if fast else (2048, 128)
    S = np.abs(librosa.stft(y, n_fft=n_fft, hop_length=hop))
    freqs = librosa.fft_frequencies(sr=sr, n_fft=n_fft)
    if S.shape[1] == 0:
        midi = pretty_midi.PrettyMIDI(initial_tempo=bpm, resolution=480)
        midi.instruments.append(pretty_midi.Instrument(program=0, is_drum=True, name="Drums"))
        return midi

    # Silêncio não deve produzir centenas de ataques com limiar zero.
    if np.max(np.abs(y), initial=0.0) < 1e-6:
        midi = pretty_midi.PrettyMIDI(initial_tempo=bpm, resolution=480)
        midi.instruments.append(pretty_midi.Instrument(0, is_drum=True, name="Drums"))
        return midi

    flux_bands = {
        "kick": (30.0, 150.0),
        "tom": (80.0, 500.0),
        "snare": (150.0, 2500.0),
        "cym_low": (2500.0, 5500.0),
        "cym_high": (5500.0, 16000.0),
    }
    flux = {}
    for name, (lo, hi) in flux_bands.items():
        mask = (freqs >= lo) & (freqs < hi)
        band = S[mask]
        values = np.maximum(0.0, np.diff(band, axis=1, prepend=band[:, :1])).sum(axis=0)
        flux[name] = scipy.ndimage.gaussian_filter1d(values, sigma=1.0)

    cym_flux = flux["cym_low"] + flux["cym_high"]
    q95 = {name: max(float(np.quantile(values, 0.95)), 1e-9) for name, values in flux.items()}
    q95["cym"] = max(float(np.quantile(cym_flux, 0.95)), 1e-9)

    # Encontre candidatos em cada banda, com limiar relativo ao stem inteiro.
    candidate_indices = []
    peaks_by_band = {}
    for name, values in flux.items():
        threshold = max(1e-8, float(np.quantile(values, 0.75)) * 0.65, float(values.max()) * 0.012)
        is_peak = (values == scipy.ndimage.maximum_filter1d(values, size=(5 if fast else 11))) & (
            values >= threshold
        )
        min_gap_s = 0.045 if name.startswith("cym") else 0.065
        min_gap = max(1, int(min_gap_s * sr / hop))
        kept = []
        for idx in np.flatnonzero(is_peak):
            idx = int(idx)
            if not kept or idx - kept[-1] >= min_gap:
                kept.append(idx)
            elif values[idx] > values[kept[-1]]:
                kept[-1] = idx
        peaks_by_band[name] = kept
        candidate_indices.extend(kept)

    # Mescle candidatos que são o mesmo ataque, mantendo a posição de maior fluxo.
    candidate_indices = sorted(set(candidate_indices))
    clusters = []
    merge_gap = max(1, int(0.020 * sr / hop))
    for idx in candidate_indices:
        if not clusters or idx - clusters[-1][-1] > merge_gap:
            clusters.append([idx])
        else:
            clusters[-1].append(idx)
    candidates = [
        max(group, key=lambda i: sum(values[i] / q95[name] for name, values in flux.items()))
        for group in clusters
    ]

    def energy(mask: np.ndarray, start: int, stop: int) -> float:
        if not np.any(mask) or stop <= start:
            return 0.0
        return float(np.square(S[mask, start:stop]).sum())

    low_mask = (freqs >= 30.0) & (freqs < 150.0)
    body_mask = (freqs >= 150.0) & (freqs < 2500.0)
    cym_low_mask = (freqs >= 2500.0) & (freqs < 5500.0)
    cym_high_mask = (freqs >= 5500.0) & (freqs < 16000.0)

    midi = pretty_midi.PrettyMIDI(initial_tempo=bpm, resolution=480)
    drum_inst = pretty_midi.Instrument(program=0, is_drum=True, name="Drums")
    t_per_frame = hop / sr
    n_frames = S.shape[1]

    for idx in candidates:
        # 80 ms de som após o ataque ajudam a distinguir o corpo da caixa do brilho do prato.
        start_frame = max(0, idx - 1)
        stop_frame = min(n_frames, idx + max(4, int(0.080 / t_per_frame)))
        e_low = energy(low_mask, start_frame, stop_frame)
        e_body = energy(body_mask, start_frame, stop_frame)
        e_cym_low = energy(cym_low_mask, start_frame, stop_frame)
        e_cym_high = energy(cym_high_mask, start_frame, stop_frame)
        total = e_low + e_body + e_cym_low + e_cym_high + 1e-12
        low_frac = e_low / total
        body_frac = e_body / total
        cym_frac = (e_cym_low + e_cym_high) / total

        kick_strength = float(flux["kick"][idx] / q95["kick"])
        snare_strength = float(flux["snare"][idx] / q95["snare"])
        cym_strength = float(cym_flux[idx] / q95["cym"])

        time = float(librosa.frames_to_time(idx, sr=sr, hop_length=hop))
        tom_pitch, sub_fraction, has_snare_noise = classify_body(y, sr, time)
        tom_strength = float(flux["tom"][idx] / q95["tom"])
        is_tom = tom_pitch is not None and tom_strength >= 0.55 and low_frac + body_frac >= 0.18
        detected = []
        if is_tom:
            velocity = int(np.clip(42 + 34 * np.sqrt(tom_strength), 35, 120))
            detected.append((tom_pitch, velocity, 0.16))

        # Bumbo: banda grave dominante e ataque também presente na banda grave.
        if low_frac >= 0.08 and kick_strength >= 0.55 and (not is_tom or sub_fraction >= 0.15):
            velocity = int(np.clip(45 + 35 * np.sqrt(kick_strength), 35, 127))
            detected.append((36, velocity, 0.10))

        # Caixa: exige corpo em médios; isso bloqueia a maioria dos pratos brilhantes.
        if body_frac >= 0.12 and snare_strength >= 0.55 and (not is_tom or has_snare_noise):
            velocity = int(np.clip(40 + 34 * np.sqrt(snare_strength), 30, 120))
            detected.append((38, velocity, 0.10))

        # Crash: usa a cauda da banda média-aguda. O brilho de um chimbal
        # simultâneo não participa dessa decisão, para um não substituir o outro.
        if cym_frac >= 0.25 and cym_strength >= 0.8:
            early_stop = min(n_frames, idx + max(2, int(0.035 / t_per_frame)))
            late_stop = min(n_frames, idx + max(4, int(0.125 / t_per_frame)))
            early = energy(cym_low_mask, start_frame, early_stop)
            late = energy(cym_low_mask, early_stop, late_stop)
            low_strength = float(flux["cym_low"][idx] / q95["cym_low"])
            if late / (early + 1e-12) >= 1.5 and low_strength >= 0.8:
                velocity = int(np.clip(90 + 8 * np.sqrt(cym_strength), 80, 115))
                detected.append((49, velocity, 0.16))

        time = float(librosa.frames_to_time(idx, sr=sr, hop_length=hop))
        for pitch, velocity, duration in detected:
            drum_inst.notes.append(pretty_midi.Note(velocity, pitch, time, time + duration))

    # O chimbal tem sua própria lista de ataques. Não há um "else" do crash:
    # as duas peças podem existir no mesmo instante quando houver evidência.
    for idx in peaks_by_band.get("cym_high", []):
        high_strength = float(flux["cym_high"][idx] / q95["cym_high"])
        early_stop = min(n_frames, idx + max(2, int(0.035 / t_per_frame)))
        late_stop = min(n_frames, idx + max(4, int(0.1 / t_per_frame)))
        first = energy(cym_high_mask, max(0, idx - 1), early_stop)
        # Vazamento minúsculo de um tom não é chimbal: normalizar uma banda
        # quase vazia pode amplificar o estalo do tom como um falso ataque.
        all_first = float(np.square(S[:, max(0, idx - 1) : early_stop]).sum())
        if first / (all_first + 1e-12) < 0.02:
            continue
        tail = energy(cym_high_mask, early_stop, late_stop)
        first_density = first / max(1, early_stop - max(0, idx - 1))
        tail_density = tail / max(1, late_stop - early_stop)
        high_flux_share = float(flux["cym_high"][idx] / (cym_flux[idx] + 1e-12))
        if high_strength < 0.4 or first <= 1e-10:
            continue
        # Ataques curtos e brilhantes; cauda longa isolada não vira um chimbal novo.
        if high_flux_share < 0.45 and tail_density >= first_density * 0.75:
            continue
        time = float(librosa.frames_to_time(idx, sr=sr, hop_length=hop))
        velocity = int(np.clip(65 + 16 * np.sqrt(high_strength), 50, 100))
        drum_inst.notes.append(pretty_midi.Note(velocity, 42, time, time + 0.055))

    suppressed = []
    last_by_pitch = {}
    for note in sorted(drum_inst.notes, key=lambda n: (n.start, n.pitch)):
        previous = last_by_pitch.get(note.pitch)
        gap = {36: 0.07, 38: 0.08, 42: 0.065, 49: 0.35}.get(note.pitch, 0.05)
        if previous is not None and note.start - previous.start < gap:
            if note.velocity > previous.velocity:
                suppressed.remove(previous)
            else:
                continue
        suppressed.append(note)
        last_by_pitch[note.pitch] = note
    drum_inst.notes = sorted(suppressed, key=lambda n: (n.start, n.pitch))
    midi.instruments.append(drum_inst)
    quantize_drums(midi, bpm, grid_times, grid)
    counts = {
        "kick": sum(1 for note in drum_inst.notes if note.pitch == 36),
        "snare": sum(1 for note in drum_inst.notes if note.pitch == 38),
        "toms": sum(1 for note in drum_inst.notes if note.pitch in TOM_NOTES),
        "hat": sum(1 for note in drum_inst.notes if note.pitch == 42),
        "crash": sum(1 for note in drum_inst.notes if note.pitch == 49),
    }
    print(
        "  [bateria] bumbo: {kick}; caixa: {snare}; tons/surdo: {toms}; chimbal/prato: {hat}; crash: {crash}".format(
            **counts
        )
    )
    return midi


def main() -> int:
    """Coordena a conversão dos stems e salva faixas individuais e o MIDI combinado."""
    ap = argparse.ArgumentParser(
        description="Converte stems de áudio em arquivos MIDI separados e combinados."
    )
    ap.add_argument(
        "--drum-grid",
        type=int,
        choices=(8, 16, 32),
        default=16,
        help="Grade própria da bateria; 16 = semicolcheias",
    )
    ap.add_argument("source", help="Pasta com os stems de áudio (ou um arquivo de áudio)")
    ap.add_argument("-o", "--output", default="saida", help="Pasta de saída (padrão: ./saida)")
    ap.add_argument(
        "--grid",
        type=int,
        choices=(0, 4, 8, 16, 32),
        default=0,
        help="Grade de quantização; 0 preserva os tempos detectados",
    )
    ap.add_argument(
        "--bpm", type=float, default=None, help="BPM manual para usar como referência (opcional)"
    )
    ap.add_argument("--reference", help="Mix original para detectar o BPM")
    ap.add_argument(
        "--quick-pitch", action="store_true", help="Estimativa YIN mais rápida para voz e baixo"
    )
    ap.add_argument(
        "--fast", action="store_true", help="Bateria e estimativa de andamento com análise reduzida"
    )
    ap.add_argument("--live-vocals", choices=("off", "balanced", "strict"), default="off")
    ap.add_argument("--crowd-ranges", default="")
    ap.add_argument(
        "--vocal-polyphonic",
        action="store_true",
        help="Preserva coros polifônicos em vez de extrair uma melodia",
    )
    ap.add_argument(
        "--no-rhythm-lock",
        action="store_true",
        help="Desativa baixo no bumbo e violão em colcheias",
    )
    ap.add_argument(
        "--note-cleanup", choices=("musical", "auto", "gentle", "off"), default="musical"
    )
    ap.add_argument("--style-profile")
    ap.add_argument("--compact", action="store_true")
    args = ap.parse_args()
    style_profile = (
        json.loads(Path(args.style_profile).read_text(encoding="utf-8"))
        if args.style_profile
        else DEFAULT_STYLE
    )
    excluded = parse_crowd_ranges(args.crowd_ranges)
    if args.bpm is not None and not (30.0 <= args.bpm <= 300.0):
        ap.error("--bpm deve estar entre 30 e 300")

    src_path = Path(args.source).expanduser().resolve()
    out = Path(args.output).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    wav_dir = out / "wav_cache"

    try:
        audio_files = scan_audio_files(src_path, out)
    except (ValueError, FileNotFoundError) as exc:
        print(f"[erro] {exc}")
        return 2
    if not audio_files:
        print(f"[erro] Nenhum áudio foi encontrado em: {src_path}")
        print("Coloque os MP3/WAV dentro da pasta indicada e execute o script novamente.")
        return 2

    stems: dict[str, Path] = {}
    metro: Path | None = None
    print(f"[entrada] Áudios encontrados: {len(audio_files)}")
    for p in audio_files:
        kind = classify_stem(p)
        if kind == "metronome":
            metro = prepare_wav(p, wav_dir)
            continue
        if kind in stems:
            raise ValueError(
                f"Dois arquivos classificados como {kind}: renomeie ou envie um por instrumento."
            )
        stems[kind] = prepare_wav(p, wav_dir)

    if not stems:
        print("[erro] Só encontrei metrônomo/click, nenhuma faixa musical para converter.")
        return 2

    if args.compact:
        accompaniment = [stems.pop(key) for key in ("guitar", "piano", "other") if key in stems]
        if len(accompaniment) == 1:
            stems["guitar"] = accompaniment[0]
        elif accompaniment:
            wav_dir.mkdir(parents=True, exist_ok=True)
            mixed = wav_dir / "acompanhamento_norm.wav"
            command = ["ffmpeg", "-y", "-nostdin"]
            for file in accompaniment:
                command.extend(["-i", str(file)])
            command.extend(
                [
                    "-filter_complex",
                    f"amix=inputs={len(accompaniment)}:duration=longest:normalize=1",
                    "-ar",
                    "22050",
                    "-ac",
                    "1",
                    str(mixed),
                ]
            )
            subprocess.run(
                command,
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            stems["guitar"] = mixed

    # Descobre a duração real das faixas para a grade cobrir a música inteira.
    durations = []
    for path in stems.values():
        try:
            durations.append(float(librosa.get_duration(path=str(path))))
        except Exception:
            pass
    max_duration = max(durations) if durations else 0.0
    if max_duration <= 0:
        print("[erro] Não consegui ler a duração dos arquivos de áudio.")
        return 2

    bpm_hint = args.bpm if args.bpm is not None else parse_bpm_hint(audio_files)
    reference_path = (
        Path(args.reference)
        if args.reference
        else (stems.get("drums") or stems.get("bass") or next(iter(stems.values())))
    )
    bpm, grid_times = analyze_metronome(
        metro,
        sub_div=max(1, args.grid // 4),
        max_duration=max_duration,
        bpm_hint=bpm_hint,
        reference_path=reference_path,
        fast=args.fast,
    )
    if args.grid and style_profile.get("grid_anchor") is not None:
        grid_times = build_grid(
            max_duration,
            bpm,
            sub_div=max(1, args.grid // 4),
            anchor=float(style_profile["grid_anchor"]),
        )
    # A bateria mantém sua grade mesmo quando o usuário preserva os tempos vocais.
    drum_anchor = float(grid_times[0]) if len(grid_times) else 0.0
    drum_grid_times = build_grid(max_duration, bpm, sub_div=args.drum_grid // 4, anchor=drum_anchor)
    print("[faixas] " + ", ".join(f"{name} ({path.name})" for name, path in sorted(stems.items())))

    midi_dir = out / "midi"
    midi_dir.mkdir(parents=True, exist_ok=True)
    combined = pretty_midi.PrettyMIDI(initial_tempo=bpm, resolution=480)
    total_notes = 0
    cleanup_reports = []

    # Cada stem usa seu detector: transientes para bateria, pYIN para voz principal,
    # Basic Pitch para instrumentos que podem tocar várias notas simultâneas.
    for track_index, (name, path) in enumerate(sorted(stems.items())):
        print(f"[progress] {track_index}/{len(stems)} {name}", flush=True)
        print(f"[convertendo] {name}...")
        if name == "drums":
            midi = transcribe_drums(path, bpm, drum_grid_times, grid=args.drum_grid, fast=args.fast)
            split_hihat(midi)
            if args.note_cleanup == "musical":
                midi = style_drums(midi, style_profile)
            hats = [i for i in midi.instruments if i.name == "Drums - Chimbal"]
            if hats:
                single_hat = pretty_midi.PrettyMIDI(initial_tempo=bpm, resolution=480)
                single_hat.instruments = hats
                single_hat.write(str(midi_dir / "hihat.mid"))
        else:
            raw = (
                transcribe_vocal_melody(path)
                if name == "vocals" and not args.vocal_polyphonic
                else transcribe_monophonic(path, name)
                if args.quick_pitch and name in ("bass", "vocals")
                else transcribe_stem(path, name)
            )
            raw_count = sum(len(inst.notes) for inst in raw.instruments)
            bass_report = None
            if name == "bass" and args.note_cleanup != "off":
                print("  [baixo] Conferindo a fundamental no áudio...", flush=True)
                raw, bass_report = validate_bass_pitch(raw, path)
            midi = rebuild_with_bpm(raw, bpm)
            midi = post_process_notes(
                midi, name, bpm, grid_times, grid=0 if args.note_cleanup == "musical" else args.grid
            )
            before_musical = copy.deepcopy(midi)
            if args.note_cleanup == "musical":
                midi = apply_style(midi, name, bpm, grid_times, args.grid, style_profile)
            if name == "vocals" and (args.live_vocals != "off" or excluded):
                print(
                    "  [ao vivo] Conferindo notas vocais; coro afinado pode continuar passando pelo filtro.",
                    flush=True,
                )
                y_vocal, sr_vocal = librosa.load(str(path), sr=16000, mono=True)
                midi, live_report = filter_vocal_notes(
                    midi,
                    y_vocal,
                    sr_vocal,
                    automatic=args.live_vocals != "off",
                    threshold=0.78 if args.live_vocals == "strict" else 0.62,
                    excluded=excluded,
                )
                try:
                    (midi_dir / "relatorio_voz.json").write_text(
                        json.dumps(live_report, ensure_ascii=False, indent=2), encoding="utf-8"
                    )
                except (OSError, TypeError, ValueError) as exc:
                    print(
                        f"  [aviso] Não consegui salvar o relatório vocal: {exc}. A geração do MIDI continua.",
                        flush=True,
                    )
                print(
                    f"  [ao vivo] {len(live_report['rejected_or_trimmed'])} notas removidas ou recortadas; sem mudar o tempo da música.",
                    flush=True,
                )
            if name in ("bass", "guitar"):
                if args.note_cleanup != "off":
                    before_cleanup = out / "antes_limpeza"
                    before_cleanup.mkdir(exist_ok=True)
                    (before_musical if args.note_cleanup == "musical" else midi).write(
                        str(before_cleanup / f"{name}.mid")
                    )
                if args.note_cleanup == "musical" and name == "bass" and bass_report and bass_report["checked"]:
                    midi, cleanup_report = clean_notes(midi, name, wav=path, mode="auto")
                    cleanup_report["mode"] = "musical"
                elif args.note_cleanup == "musical":
                    cleanup_report = {
                        "stem": name,
                        "mode": "musical",
                        "before": raw_count,
                        "after": sum(len(i.notes) for i in midi.instruments),
                        "max_polyphony_before": max_polyphony(raw.instruments[0].notes)
                        if raw.instruments
                        else 0,
                        "max_polyphony_after": max_polyphony(
                            [n for i in midi.instruments for n in i.notes]
                        ),
                    }
                else:
                    midi, cleanup_report = clean_notes(midi, name, wav=path, mode=args.note_cleanup)
                if bass_report is not None:
                    cleanup_report["pitch_validation"] = bass_report
                cleanup_reports.append(cleanup_report)
                print(
                    f"  [limpeza] {name}: {cleanup_report['before']} → {cleanup_report['after']} notas; simultâneas {cleanup_report['max_polyphony_before']} → {cleanup_report['max_polyphony_after']}",
                    flush=True,
                )
            prog, label = GM_PROGRAMS.get(name, (0, name.title()))
            prog = int(style_profile.get("stats", {}).get(name, {}).get("program", prog))
            for inst in midi.instruments:
                inst.program, inst.name = prog, label
            final_count = sum(len(inst.notes) for inst in midi.instruments)
            print(f"  [notas] antes dos filtros: {raw_count}; depois dos filtros: {final_count}")

        if name == "bass":
            for instrument in midi.instruments:
                for note in instrument.notes:
                    note.pitch = min(127, note.pitch + 12)
            print("  [baixo] Oitava elevada em +12 semitons.", flush=True)

        out_file = midi_dir / f"{name}.mid"
        midi.write(str(out_file))
        count = sum(len(inst.notes) for inst in midi.instruments)
        total_notes += count
        end_time = max((n.end for inst in midi.instruments for n in inst.notes), default=0.0)
        print(f"  -> {out_file.name}: {count} notas, duração MIDI {end_time:.2f}s")
        if count == 0:
            print(
                f"  [aviso] {name}.mid ficou vazio: o detector não produziu notas ou os filtros removeram todas."
            )
        for inst in midi.instruments:
            combined.instruments.append(inst)
        print(f"[progress] {track_index + 1}/{len(stems)} {name} concluída", flush=True)

    # Depois de detectar as alturas, simplifica o arranjo usando bumbo e grade.
    if not args.no_rhythm_lock:
        rhythm_report = lock_rhythm(combined.instruments, bpm, grid_times)
        try:
            (midi_dir / "relatorio_ritmo.json").write_text(
                json.dumps(rhythm_report, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except (OSError, TypeError, ValueError) as exc:
            print(f"[aviso] Relatório rítmico indisponível: {exc}")
        for name in stems:
            file = midi_dir / f"{name}.mid"
            single = pretty_midi.PrettyMIDI(initial_tempo=bpm, resolution=480)
            label = GM_PROGRAMS.get(name, (0, name.title()))[1]
            single.instruments = [
                i
                for i in combined.instruments
                if (i.is_drum if name == "drums" else i.name == label)
            ]
            if single.instruments:
                single.write(str(file))
        for report in cleanup_reports:
            label = GM_PROGRAMS.get(report["stem"], (0, report["stem"].title()))[1]
            final = [n for i in combined.instruments if i.name == label for n in i.notes]
            report["before_rhythm"] = report["after"]
            report["after"] = len(final)
            report["max_polyphony_after"] = max_polyphony(final)
        total_notes = sum(len(i.notes) for i in combined.instruments)
        print(f"[ritmo] Baixo no bumbo; violão em colcheias: {rhythm_report}", flush=True)

    try:
        (midi_dir / "relatorio_limpeza.json").write_text(
            json.dumps({"tracks": cleanup_reports}, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except (OSError, TypeError, ValueError) as exc:
        print(f"[aviso] Relatório de limpeza não foi salvo: {exc}")
    combined_file = midi_dir / "completo.mid"
    combined.write(str(combined_file))
    combined_end = max((n.end for inst in combined.instruments for n in inst.notes), default=0.0)
    print(f"\n[ok] Arquivos salvos em: {midi_dir}")
    print(f"[resumo] Total de notas: {total_notes}; duração do MIDI completo: {combined_end:.2f}s")
    if total_notes == 0:
        print(
            "[problema] O MIDI saiu com 0 segundos porque nenhuma nota foi gerada. Confira as linhas '[notas]' acima."
        )
        print(
            "Se 'antes dos filtros' for 0, o problema está na transcrição/Basic Pitch; se só cair depois dos filtros, os limites de notas estão restritivos."
        )
        if args.live_vocals != "off" or excluded:
            print("[ao vivo] Filtro pode deixar a faixa vocal vazia; MIDI salvo para revisão.")
            return 0
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
